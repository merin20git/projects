<!-- <?php
include('connection.php');

function handle_error($message) {
    $response = array(
        'status' => 0,
        'message' => $message
    );

    echo json_encode($response);
    exit; // Terminate script execution
}

?> -->
<?php
// error_handling.php

if (!function_exists('handle_error')) {
    function handle_error($errno, $errstr, $errfile, $errline) {
        // Your error handling code here
        echo "Error: [$errno] $errstr - $errfile:$errline";
    }

    set_error_handler("handle_error");
}
?>

