<?php 
include("connection.php");
$name=$_POST['name'];
$password=$_POST['password'];
// $name="sree";
// $password="12345sree";
$query="select * from supere_mart where name='$name' && password='$password'";
$result=mysqli_query($con,$query);
$row=mysqli_fetch_row($result);
if(mysqli_num_rows($result)>0){
    $response["status"]="1";
    $response["message"]="Login Successful";
    $response["id"]=$row[0]; 
    $response["name"]=$row[1];
    $response["address"]=$row[2];
    $response["email"]=$row[3];
    $response["place"]=$row[4]; 
    $response["phone"]=$row[5];
    $response["session_password"]=$row[6];
    $response["gender"]=$row[7];
  
 
}
else{
    $response["status"]="0";
    $response["message"]="Login Failed";
}
echo json_encode($response);
?>