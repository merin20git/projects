<?php
include("connection.php");
$shop_id=$_POST['shop_id'];
$stmt = $con->prepare("SELECT product_name,price,category,offer,stock,image FROM details WHERE shop_id='$shop_id' && stock=0");

   $stmt->execute();
    
   $stmt->bind_result($product_name,$price,$offer,$stock,$category,$image);
    
    $products = array(); 
    

    while($stmt->fetch()){
        $temp = array();

        $temp['product_name']=$product_name;
        $temp['price']=$price;
        $temp['offer']=$offer;
        $temp['stock']=$stock;
        $temp['category']=$category;
      $temp['image']=$image;
        
        array_push($products, $temp);
    }
    
     
    echo json_encode($products);
?>
