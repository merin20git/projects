<?php
include("connection.php");
$name=$_POST['name'];
$address=$_POST['address'];
$email=$_POST['email'];
$place=$_POST['place'];
$phone=$_POST['phone'];
$password=$_POST['password'];
$gender=$_POST['gender'];
$query="insert into supere_mart(name,address,email,place,phone,password,gender)
 values('$name','$address','$email','$place','$phone','$password','$gender')";
$result=mysqli_query($con,$query);
if($result){
    $response["status"]="1";
    $response["message"]="Registration Successful";
}
else{
    $response["status"]="0";
    $response["message"]="Registration Failed";
}
echo json_encode($response);
?>
