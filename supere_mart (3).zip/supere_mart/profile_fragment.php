<?php
include("connection.php");
$id=$_POST['id'];
$name=$_POST['name'];
$address=$_POST['address'];
$email=$_POST['email'];
$place=$_POST['place'];
$contact=$_POST['phone'];
$password=$_POST['password'];
$query="UPDATE supere_mart set name='$name',address='$address',email='$email',place='$place',phone='$contact',password='$password' where id='$id' ";
$result=mysqli_query($con,$query);
if($result){
    $response["status"]="1";
    $response["message"]="Registration Successful";
}
else{
    $response["status"]="0";
    $response["message"]="Registration Failed";
}
echo json_encode($response);
?>