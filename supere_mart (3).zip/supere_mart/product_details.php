<?php
include("connection.php");
$name1=$_POST['name1'];
$price1=$_POST['price1'];
$offer1=$_POST['offer1'];
$shop=$_POST['shop'];
$caT=$_POST['caT'];
$stock=$_POST['stock'];
$query="insert into details(product_name,price,offer,stock,shop,category)
 values('$name1','$price1','$offer1','$shop','$caT')";
$result=mysqli_query($con,$query);
if($result){
    $response["status"]="1";
    $response["message"]="Successful";
}
else{
    $response["status"]="0";
    $response["message"]="Failed";
}
echo json_encode($response);
?>
