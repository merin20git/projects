<?php
include("connection.php");

// Assuming you receive user_id as a parameter
$user_id = $_POST['user_id'];

// Step 1: Retrieve data from cart
$select_cart_query = "SELECT produt_id, prodct_quantity FROM cart WHERE user_id = ?";
$stmt_select_cart = $con->prepare($select_cart_query);
$stmt_select_cart->bind_param("s", $user_id);
$stmt_select_cart->execute();
$result_cart = $stmt_select_cart->get_result();

// Step 2: Initialize arrays to store product IDs and quantities
$product_ids = array();
$product_quantities = array();

// Iterate through each row in the cart and store data in arrays
while ($row_cart = $result_cart->fetch_assoc()) {
    $product_ids[] = $row_cart['produt_id'];
    $product_quantities[] = $row_cart['prodct_quantity'];
}

// Step 3: Delete rows from cart
$delete_cart_query = "DELETE FROM cart WHERE user_id = ?";
$stmt_delete_cart = $con->prepare($delete_cart_query);
$stmt_delete_cart->bind_param("s", $user_id);
$stmt_delete_cart->execute();

// Step 4: Update details table
$update_details_query = "UPDATE details SET stock = stock - ? WHERE id = ?";
$stmt_update_details = $con->prepare($update_details_query);

// Iterate through the arrays and update details table
for ($i = 0; $i < count($product_ids); $i++) {
    $produt_id = $product_ids[$i];
    $prodct_quantity = $product_quantities[$i];

    $stmt_update_details->bind_param("is", $prodct_quantity, $produt_id);
    $stmt_update_details->execute();
}

// Close prepared statements
$stmt_select_cart->close();
$stmt_delete_cart->close();
$stmt_update_details->close();

// Close database connection
$con->close();

// Provide a response indicating success or failure
$response = array();

if ($stmt_delete_cart && $stmt_update_details) {
    $response["status"] = "1";
    $response["message"] = "Data updated successfully";
} else {
    $response["status"] = "0";
    $response["message"] = "Failed to update data";
}

echo json_encode($response);
?>
