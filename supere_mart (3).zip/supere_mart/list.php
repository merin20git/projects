<?php
include("connection.php");
$shop=$_POST['shop'];

$stmt = $con->prepare("SELECT id,shop_id,shop,category,email,phone,image FROM advertisement where shop='$shop'");

   $stmt->execute();
    
    $stmt->bind_result($id,$shop_id,$shop,$category,$email,$phone,$image);
    
    $products = array(); 
    

    while($stmt->fetch()){
        $temp = array();
        $temp['id'] = $id;
        $temp['shop_id']=$shop_id;
        $temp['shop']=$shop;
        $temp['category']=$category;
        $temp['email']=$email;
        $temp['phone']=$phone;
        $temp['image']=$image;

        array_push($products, $temp);
    }
    
     
    echo json_encode($products);
?>