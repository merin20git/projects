<?php
include("connection.php");
$shop_id=$_POST['shop_id'];
$stmt = $con->prepare("SELECT id,user_id,user_name,user_phn,user_address,produt_id,product_name,prodct_quantity,total_amont,stock,s_id,s_name,s_cat,p_image FROM cart where user_id='$shop_id'");

   $stmt->execute();
    
    $stmt->bind_result($id,$user_id,$user_name,$user_phn,$user_address,$produt_id,$product_name,$prodct_quantity,$total_amont,$stock,$s_id,$s_name,$s_cat,$p_image);
    
    $products = array(); 
    

    while($stmt->fetch()){
        $temp = array();
        $temp['id'] = $id;
        $temp['user_id']=$user_id;
        $temp['user_name']=$user_name;
        $temp['user_phn']=$user_phn;
        $temp['user_address']=$user_address;
        $temp['produt_id']=$produt_id;
        $temp['product_name']=$product_name;
        $temp['prodct_quantity']=$prodct_quantity;
        $temp['total_amont']=$total_amont;
        $temp['stock']=$stock;
        $temp['s_id']=$s_id;
        $temp['s_name']=$s_name;
        $temp['s_cat']=$s_cat;
        $temp['p_image']=$p_image;
        array_push($products, $temp);
    }
    
    
     
    echo json_encode($products);
?>
