<?php
include("connection.php");
$name=$_POST['id'];

$query="Delete from cart where id='$name'";
$result=mysqli_query($con,$query);
if($result){
    $response["status"]="1";
    $response["message"]="deleted Successful";
}
else{
    $response["status"]="0";
    $response["message"]="deleted Failed";
}
echo json_encode($response);
?>
