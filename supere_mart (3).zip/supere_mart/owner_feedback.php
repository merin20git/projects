<?php
include("connection.php");
$owner=$_POST['owner_name'];
$customer=$_POST['cust_name'];
$phone=$_POST['cust_phone'];
$complaint=$_POST['complaint'];
$query="insert into owner_feedback(owner_name,cust_name,cust_phone,complaint)
 values('$owner','$customer','$phone','$complaint')";
$result=mysqli_query($con,$query);
if($result){
    $response["status"]="1";
    $response["message"]="Complaint Registration";
    
}
else{
    $response["status"]="0";
    $response["message"]="Complaint Failed";
}
echo json_encode($response);
?>