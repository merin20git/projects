<?php
include("connection.php");
$id=$_POST['id'];
$name=$_POST['name'];
$email=$_POST['email'];
$place=$_POST['place'];
$contact=$_POST['phone'];
$password=$_POST['password'];
$query="UPDATE owner set name='$name',email='$email',place='$place',phone='$contact',password='$password' where id='$id' ";
 
$result=mysqli_query($con,$query);
if($result){
    $response["status"]="1";
    $response["message"]="Updated Successfully";
}
else{
    $response["status"]="0";
    $response["message"]=" Failed";
}
echo json_encode($response);
?>