<?php
include("connection.php");
// $sid=$_POST['shop_id'];
$stmt = $con->prepare("SELECT id,feedback,name,place FROM feedback");

   $stmt->execute();
    
    $stmt->bind_result($id,$feedback,$name,$place);
    
    $products = array(); 
    

    while($stmt->fetch()){
        $temp = array();
        $temp['id'] = $id;
        $temp['feedback']=$feedback;
        $temp['name']=$name;
        $temp['place']=$place;
        
        
        array_push($products, $temp);
    }
    
     
    echo json_encode($products);
?>
