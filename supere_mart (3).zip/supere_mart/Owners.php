<?php
include("connection.php");
$sid=$_POST['id'];
$stmt = $con->prepare("SELECT id,shop,email,place,phone,password,image FROM owner where id='$sid'");

   $stmt->execute();
    
    $stmt->bind_result($id,$name,$email,$place,$phone,$password,$image);
    
    $products = array(); 
    

    while($stmt->fetch()){
        $temp = array();
        $temp['id']=$id;
         $temp['shop']=$name;
    $temp['email']=$email;
        $temp['place']=$place;
        $temp['phone']=$phone;
        $temp['pass']=$password;
        $temp['img']=$image;
   

        array_push($products, $temp);
    }
    
     
    echo json_encode($products);
?>