<?php
include("connection.php");
$feedback=$_POST["rating"];
$username=$_POST["name"];
$place=$_POST["place"];

$q="insert into feedback(feedback,name,place)
values('$feedback','$username','$place')";
$result=mysqli_query($con,$q);
if ($result)
{
    $response['status']="1";
    $response['message']="success";
}
else{
    $response['status']="0";
    $response['message']="saved";
   
}
echo json_encode($response);
?>
