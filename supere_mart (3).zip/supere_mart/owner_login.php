<?php 
include("connection.php");

// Assuming you're receiving 'shop' and 'password' via POST method
$name = $_POST['shop'];
$password = $_POST['password'];
$status = "approved";

// Using prepared statement to prevent SQL injection
$query = "SELECT * FROM owner WHERE shop=? AND password=? AND status=?";
$stmt = mysqli_prepare($con, $query);

// Bind parameters and execute the query
mysqli_stmt_bind_param($stmt, "sss", $name, $password, $status);
mysqli_stmt_execute($stmt);

// Get the result set
$result = mysqli_stmt_get_result($stmt);

// Check if there are any rows returned
if(mysqli_num_rows($result) > 0){
    // Fetch the row as an associative array
    $row = mysqli_fetch_assoc($result);

    // Prepare the response array
    $response = array(
        'status' => "1",
        'message' => "Login Successful",
        'id' => $row['id'], 
        'owner_name' => $row['owner_name'], 
        'shop' => $row['shop'],
        'email' => $row['email'],
        'place' => $row['place'], 
        'phone' => $row['phone'],
        'password' => $row['password']
    );
} else {
    // No rows returned, prepare failure response
    $response = array(
        'status' => "0",
        'message' => "Login Failed",
        'id' => "",
        'owner_name' => "",
        'shop' => "",
        'email' => "",
        'place' => "",
        'phone' => "",
        'password' => ""
    );
}

// Encode the response array to JSON and output
echo json_encode($response);
?>
