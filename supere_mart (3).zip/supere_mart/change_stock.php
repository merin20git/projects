<!-- <?php
include("connection.php");
$id=$_POST['product_id'];
$stock=$_POST['Stock'];

$query="UPDATE details set stock='$stock' where id='$id' ";
$result=mysqli_query($con,$query);
if($result){
    $response["status"]="1";
    $response["message"]="stock updated";
}
else{
    $response["status"]="0";
    $response["message"]=" Failed";
}
echo json_encode($response);
?> -->

<?php
include("connection.php");

// Assuming you receive both product_id and Stock for details table
$id = $_POST['product_id'];
$stock = $_POST['Stock'];
$cart_id = $_POST['cart_id'];
$cartStock = $_POST['cart_Stock'];

// Update stock in the details table
$queryDetails = "UPDATE details SET stock='$stock' WHERE id='$id'";
$resultDetails = mysqli_query($con, $queryDetails);

// Assuming you also receive cart_id and CartStock for cart table


// Update stock in the cart table
$queryCart = "UPDATE cart SET stock='$cartStock' WHERE produt_id='$cart_id'";
$resultCart = mysqli_query($con, $queryCart);

$response = array();

if ($resultDetails && $resultCart) {
    $response["status"] = "1";
    $response["message"] = "Stock updated in both tables";
} else {
    $response["status"] = "0";
    $response["message"] = "Failed to update stock";
}

echo json_encode($response);
?>