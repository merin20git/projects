<?php
include ("connection.php");
$id=$_POST['Product_ID'];
$stock=$_POST['Stock'];

$query="Update details set stock='$stock' where id='$id'";
$result=mysqli_query($con,$query);
if($result){
    $response["status"]="1";
    $response["message"]="Updated Successful";
}
else{
    $response["status"]="0";
    $response["message"]="Updated Failed";
}
echo json_encode($response);
?>
