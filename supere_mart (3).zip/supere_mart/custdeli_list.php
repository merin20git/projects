<?php
include("connection.php");
$shop_id
$stmt = $con->prepare("SELECT id,name,address,phone_no,items,quantity,shop_is FROM delivery where shop_id='$shop_id'");

   $stmt->execute();
    
    $stmt->bind_result($id,$name,$address,$phone_no,$items,$quantity,$shop_id);
    
    $products = array(); 
    

    while($stmt->fetch()){
        $temp = array();
        $temp['id'] = $id;
        $temp['name']=$name;
        $temp['address']=$address;
        $temp['phone_no']=$phone_no;
        $temp['items']=$items;
        $temp['quantity']=$quantity;
        $temp['shop_id']=$shop_id;

        array_push($products, $temp);
    }
    
     
    echo json_encode($products);
?>
