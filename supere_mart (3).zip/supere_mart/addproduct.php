<?php
include("connection.php");
$name1=$_POST['name1'];
$price1=$_POST['price1'];
$offer1=$_POST['offer1'];
$shop=$_POST['shop'];
$shopid=$_POST['shopid'];
$caT=$_POST['caT'];
$stock=$_POST['stock'];


$originalImgName=$_FILES['filename']['name'];
$tempName=$_FILES['filename']['tmp_name'];
$folder="uploads/";

if(move_uploaded_file($tempName,$folder.$originalImgName)){
    $query="insert into details(product_name,price,offer,stock,shop,category,shop_id,image)
    values('$name1','$price1','$offer1','$stock','$shop','$caT','$shopid','$originalImgName')";
     if(mysqli_query($con,$query)){
   $response['status']="1";
   $response['message']="file uploaded successfully";  

}
else{
    $response['status']="0";
    $response['message']="Data insertion failed";
}
}
else{
    $response['status']="0";
    $response['message']="File moving failed";
}
echo json_encode($response);
?>
