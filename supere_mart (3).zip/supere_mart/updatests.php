<?php
include("connection.php");
$id=$_POST['tid'];
$name=$_POST['sts'];

$query="UPDATE buy set status='$name' where id='$id' ";
$result=mysqli_query($con,$query);
if($result){
    $response["status"]="1";
    $response["message"]="order status Added";
}
else{
    $response["status"]="0";
    $response["message"]=" Failed";
}
echo json_encode($response);
?>