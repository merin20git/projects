<?php
include("connection.php");
$id=$_POST['id'];

$query="Delete from details where id='$id'";
$result=mysqli_query($con,$query);
if($result){
    $response["status"]="1";
    $response["message"]="deleted Successful";
}
else{
    $response["status"]="0";
    $response["message"]="deleted Failed";
}
echo json_encode($response);
?>