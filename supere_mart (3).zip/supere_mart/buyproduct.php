<?php
include("connection.php");
$uid = $_POST["user_id"];
$uname = $_POST["user_name"];
$uphn = $_POST["user_phn"];
$uadd = $_POST["user_address"];
$pid = $_POST["produt_id"];
$pname=$_POST["product_name"];
$pq = $_POST["prodct_quantity"];
$total = $_POST["total_amont"];
$sid = $_POST["shop_id"];
$sname = $_POST["s_name"];
$scat = $_POST["s_cat"];
$simg = $_POST["p_image"];
$pay = $_POST["paymethod"];
$sts = "Not Delivered";
$cartid = $_POST["cart_id"];

// Insert the order into the 'buy' table
$query = "INSERT INTO buy (cart_id, user_id, user_name, user_phn, user_address, produt_id, product_name, prodct_quantity, total_amont, paymethod, s_id, s_name, s_cat, p_image, status)
          VALUES ('$cartid', '$uid', '$uname', '$uphn', '$uadd', '$pid', '$pname', '$pq', '$total', '$pay', '$sid', '$sname', '$scat', '$simg', '$sts')";
$result = mysqli_query($con, $query);

if ($result) {
    // Update the stock quantity in the 'details' table
    $update_query = "UPDATE details SET stock = stock - '$pq' WHERE id = '$pid'";
    $update_result = mysqli_query($con, $update_query);

    if ($update_result) {
        // Increment the score of the user
        $select_query = "SELECT * FROM supere_mart WHERE id = '$uid'";
        $select_result = mysqli_query($con, $select_query);

        if ($select_result && $row0 = mysqli_fetch_array($select_result)) {
            $score = $row0['score'] + 1;
            $update_score_query = "UPDATE supere_mart SET score = '$score' WHERE id = '$uid'";
            mysqli_query($con, $update_score_query);
        }

        $response["status"] = "1";
        $response["message"] = "Order placed successfully";
    } else {
        $response["status"] = "0";
        $response["message"] = "Failed to update stock quantity";
    }
} else {
    $response["status"] = "0";
    $response["message"] = "Failed to place order";
}

echo json_encode($response);
?>
