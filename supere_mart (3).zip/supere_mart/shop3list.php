<?php
include("connection.php");
$shop=$_POST['shop'];
$cat=$_POST['cat'];
$stmt = $con->prepare("SELECT id,product_name,price,offer,stock,shop,category,shop_id,image FROM details where category='$cat' && shop='$shop'");

   $stmt->execute();
    
    $stmt->bind_result($id,$product_name,$price,$offer,$stock,$shop,$category,$shop_id,$image);
    
    $products = array(); 
    

    while($stmt->fetch()){
        $temp = array();
        $temp['id'] = $id;
        $temp['product_name']=$product_name;
        $temp['price']=$price;
        $temp['offer']=$offer;
        $temp['stock']=$stock;
        $temp['shop']=$shop;
        $temp['category']=$category;
        $temp['shop_id']=$shop_id;
        $temp['image']=$image;

        array_push($products, $temp);
    }
    
     
    echo json_encode($products);
?>