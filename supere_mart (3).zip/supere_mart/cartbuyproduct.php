<?php
include("connection.php");

$userid = $_POST['user_id'];
$paymethod = $_POST['paymethod'];
$status = "Not Delivered";

$response = array();

$q = "INSERT IGNORE INTO buy (
    cart_id,user_id, user_name, user_phn, user_address, produt_id, product_name,
    prodct_quantity, total_amont, s_id, s_name, s_cat, p_image, paymethod, status
) 
SELECT 
cart_id,user_id, user_name, user_phn, user_address, produt_id, product_name,
    prodct_quantity, total_amont, s_id, s_name, s_cat, p_image, ?, ?
FROM cart 
WHERE user_id = ?";

// Use prepared statement to prevent SQL injection
$stmt = $con->prepare($q);

if (!$stmt) {
    // Handle the error gracefully
    $response["status"] = "0";
    $response["message"] = "Prepare failed: (" . $con->errno . ") " . $con->error;
    echo json_encode($response);
    exit;
}

$stmt->bind_param("sss", $paymethod, $status, $userid);



if (!$stmt->execute()) {
    // Handle the error gracefully
    $response["status"] = "0";
    $response["message"] = "Execute failed: (" . $stmt->errno . ") " . $stmt->error;
} else {
    // Success
    $response["status"] = "1";
    $response["message"] = "Ordered Successfully";
}

$stmt->close();
echo json_encode($response);
?>




    // Insertion into 'buy' successful

    <!-- <?php
include("connection.php");

$userid = $_POST['user_id'];
$paymethod = $_POST['paymethod'];
$status = "Not Delivered";

// Insert into 'buy' table
$q = "INSERT INTO buy (
    user_id, user_name, user_phn, user_address, produt_id, product_name,
    prodct_quantity, total_amont, s_id, s_name, s_cat, p_image, paymethod, status
) 
SELECT 
    user_id, user_name, user_phn, user_address, produt_id, product_name,
    prodct_quantity, total_amont, s_id, s_name, s_cat, p_image, ?, ?
FROM cart 
WHERE user_id = '$userid'";

// Use prepared statement to prevent SQL injection
$stmt = $con->prepare($q);
$stmt->bind_param("ss", $paymethod, $status);
$stmt->execute();
$stmt->close();

// Update stock in 'details' table
if ($stmt) {
    $produt_id = $_POST['produt_id']; // Assuming this is the product ID
    $prodct_quantity = $_POST['prodct_quantity']; // Assuming this is the quantity purchased

    // Use prepared statement to prevent SQL injection
    $updateStockQuery = "UPDATE details SET stock = stock - ? WHERE id = ?";
    $updateStockStmt = $con->prepare($updateStockQuery);
    $updateStockStmt->bind_param("ss", $prodct_quantity, $produt_id);
    $updateStockStmt->execute();
    $updateStockStmt->close();

    // Delete from 'cart' table
    $deleteFromCartQuery = "DELETE FROM cart WHERE user_id = ? AND produt_id = ?";
    $deleteFromCartStmt = $con->prepare($deleteFromCartQuery);
    $deleteFromCartStmt->bind_param("ss", $userid, $produt_id);
    $deleteFromCartStmt->execute();
    $deleteFromCartStmt->close();



   



    $response = array(
        "status" => "1",
        "message" => "Ordered Successfully. Stock Updated. Removed from Cart.",
    );
} else {
    $response = array(
        "status" => "0",
        "message" => "Failed",
    );
}

echo json_encode($response);
?> -->
