<?php
include("connection.php");

$stmt = $con->prepare("SELECT id,shop,email,place,phone,password,image,status FROM owner");

   $stmt->execute();
    
    $stmt->bind_result($id,$shop,$email,$place,$phn,$pass,$image,$status);
    
    $products = array(); 
    

    while($stmt->fetch()){
        $temp = array();
        $temp['id'] = $id;
        $temp['name']=$shop;
        $temp['email']=$email;
        $temp['place']=$place;
        $temp['phone']=$phn;
        $temp['pass']=$pass;
        $temp['img']=$image;
   
        $temp['status']=$status;
        array_push($products, $temp);
    }
    
     
    echo json_encode($products);
?>