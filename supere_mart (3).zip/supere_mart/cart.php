<?php
include("connection.php");
$uid=$_POST["user_id"];
$uname=$_POST["user_name"];
$uphn=$_POST["user_phn"];
$uadd=$_POST["user_address"];
$pid=$_POST["produt_id"];
$pname=$_POST["product_name"];
$pq=$_POST["prodct_quantity"];
$total=$_POST["total_amont"];
$cstock=$_POST["stock"];
$sid=$_POST["shop_id"];
$sname=$_POST["s_name"];
$scat=$_POST["s_cat"];
$simg=$_POST["p_image"];
$cid=$_POST["cart_id"];
$query="insert into cart(cart_id,user_id,user_name,user_phn,user_address,produt_id,product_name,prodct_quantity,total_amont,stock,s_id,s_name,s_cat,p_image)
 values('$cid','$uid','$uname','$uphn','$uadd','$pid','$pname','$pq','$total','$cstock','$sid','$sname','$scat','$simg')";
$result=mysqli_query($con,$query);
if($result){
    $response["status"]="1";
    $response["message"]="place order Successfully";
}
else{
    $response["status"]="0";
    $response["message"]=" Failed";
}
echo json_encode($response);
?>
