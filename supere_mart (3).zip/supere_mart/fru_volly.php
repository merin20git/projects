<?php
include("connection.php");
$shop=$_POST['sname'];
$cat=$_POST['sprice'];
$id=$_POST['soffer'];
$phone=$_POST['shop'];
$email=$_POST['caT'];

$originalImgName=$_FILES['filename']['name'];
$tempName=$_FILES['filename']['tmp_name'];
$folder="upload/";

if(move_uploaded_file($tempName,$folder.$originalImgName)){
    $query="insert into details(shop_id,shop,category,email,phone,image)
    values('$id','$shop','$cat','$email','$phone','$originalImgName')";
     if(mysqli_query($con,$query)){
   $response['status']="1";
   $response['message']="file uploaded successfully";  

}
else{
    $response['status']="0";
    $response['message']="Data insertion failed";
}
}
else{
    $response['status']="0";
    $response['message']="File moving failed";
}
echo json_encode($response);
?>
