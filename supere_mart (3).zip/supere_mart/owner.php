<?php
include("connection.php");
$owner_name=$_POST['owner_name'];
$shop=$_POST['shop'];
$email=$_POST['email'];
$place=$_POST['place'];
$phone=$_POST['phone'];
$password=$_POST['password'];
$query="insert into owner(owner_name,shop,email,place,phone,password)
 values('$owner_name','$shop','$email','$place','$phone','$password')";
$result=mysqli_query($con,$query);
if($result){
    $response["status"]="1";
    $response["message"]="Registration is under review";
    
}
else{
    $response["status"]="0";
    $response["message"]="Registration Failed";
    $response["owner_name"]="";
    $response["shop"]="";
    $response["email"]="";
    $response["place"]="";
    $response["phone"]="";
    $response["password"]="";

}
echo json_encode($response);
?>