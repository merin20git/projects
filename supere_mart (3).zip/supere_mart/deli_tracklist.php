<?php
include("connection.php");
$user_id=$_POST['user_id'];
$stmt = $con->prepare("SELECT p_image,product_name,total_amont,s_name,status FROM buy WHERE user_id=?");

$stmt->bind_param("s", $user_id);
$stmt->execute();
    
$stmt->bind_result($p_image,$product_name,$total_amont,$s_name,$status);
    
$products = array(); 

while($stmt->fetch()){
    $temp = array();
    
    $temp['p_image']=$p_image;
    $temp['product_name']=$product_name;
    $temp['total_amont']=$total_amont;
    $temp['s_name']=$s_name;
    $temp['status']=$status;
    
    array_push($products, $temp);
}

echo json_encode($products);
?>
