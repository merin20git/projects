<?php
include 'connection.php';
$b=$_GET['id'];
$query="delete from supere_mart where id='$b'";
$res=mysqli_query($link,$query);
if($res)
{
?>
<script language="javascript">alert('deleted successfully');window.location.replace('tables.php');</script>

<?php
}
else
{
?>

<script language="javascript">alert('deletion failed');window.location.replace('tables.php');</script>

<?php
}

?>
