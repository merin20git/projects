<?php
$email = $_POST['login'];
$password = $_POST['password'];

if($email=="admin@gmail.com" && $password == "admin"){
    ?>
    <script language="javascript">alert('Login successfull');
    window.location.replace('index.html');</script>
    <?php

}
else{

    ?>
    <script language="javascript">alert('Login successfull');
    window.location.replace('login.html');</script>
    <?php

}