<!DOCTYPE html>
<html lang="en" class="">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Tables - Admin One Tailwind CSS Admin Dashboard</title>

  <!-- Tailwind is included -->
  <link rel="stylesheet" href="css/main.css?v=1652870200386">

  <link rel="apple-touch-icon" sizes="180x180" href="apple-touch-icon.png"/>
  <link rel="icon" type="image/png" sizes="32x32" href="favicon-32x32.png"/>
  <link rel="icon" type="image/png" sizes="16x16" href="favicon-16x16.png"/>
  <link rel="mask-icon" href="safari-pinned-tab.svg" color="#00b4b6"/>

  <meta name="description" content="Admin One - free Tailwind dashboard">

  <meta property="og:url" content="https://justboil.github.io/admin-one-tailwind/">
  <meta property="og:site_name" content="JustBoil.me">
  <meta property="og:title" content="Admin One HTML">
  <meta property="og:description" content="Admin One - free Tailwind dashboard">
  <meta property="og:image" content="https://justboil.me/images/one-tailwind/repository-preview-hi-res.png">
  <meta property="og:image:type" content="image/png">
  <meta property="og:image:width" content="1920">
  <meta property="og:image:height" content="960">

  <meta property="twitter:card" content="summary_large_image">
  <meta property="twitter:title" content="Admin One HTML">
  <meta property="twitter:description" content="Admin One - free Tailwind dashboard">
  <meta property="twitter:image:src" content="https://justboil.me/images/one-tailwind/repository-preview-hi-res.png">
  <meta property="twitter:image:width" content="1920">
  <meta property="twitter:image:height" content="960">

  <!-- Global site tag (gtag.js) - Google Analytics -->
  <script async src="https://www.googletagmanager.com/gtag/js?id=UA-130795909-1"></script>
  <script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());
    gtag('config', 'UA-130795909-1');
  </script>

</head>
<body>

<div id="app">

<aside class="aside is-placed-left is-expanded">
  <div class="aside-tools">
    <div>
      Admin <b class="font-black">One</b>
    </div>
  </div>
  <div class="menu is-menu-main">
    <p class="menu-label">General</p>
    <ul class="menu-list">
      <li class="active">
        <a href="index.html">
          <span class="icon"><i class="mdi mdi-desktop-mac"></i></span>
          <span class="menu-item-label">Dashboard</span>
        </a>
      </li>
    </ul>
    <p class="menu-label">Examples</p>
    <ul class="menu-list">
      <li class="--set-active-forms-html">
        <a href="tables.php">
          <span class="icon"><i class="mdi mdi-square-edit-outline"></i></span>
          <span class="menu-item-label">Owner</span>
        </a>
      </li>
      <li class="--set-active-tables-html">
        <a href="customer.php">
          <span class="icon"><i class="mdi mdi-table"></i></span>
          <span class="menu-item-label">Customer</span>
        </a>
      </li>
      <li class="--set-active-forms-html">
        <a href="buy.php">
          <span class="icon"><i class="mdi mdi-square-edit-outline"></i></span>
          <span class="menu-item-label">Buy</span>
        </a>
      </li>

      <li class="--set-active-profile-html">
        <a href="advertisement.php">
          <span class="icon"><i class="mdi mdi-account-circle"></i></span>
          <span class="menu-item-label">Advertisement</span>
        </a>
      </li>
      <li>
        <a href="feedback.php">
          <span class="icon"><i class="mdi mdi-lock"></i></span>
          <span class="menu-item-label">Feedback</span>
        </a>
      </li>
      <li class="--set-active-forms-html">
        <a href="owner_feedback.php">
          <span class="icon"><i class="mdi mdi-square-edit-outline"></i></span>
          <span class="menu-item-label">Complaints</span>
        </a>
      </li>
      <li>
        
        <ul>
          <li>
         
          </li>
          <li>
            
          </li>
        </ul>
      </li>
    </ul>
   
    <ul class="menu-list">
      <li>
       
      </li>
      <li>
       
      </li>
    </ul>
  </div>
</aside>

<section class="is-title-bar">
  <div class="flex flex-col md:flex-row items-center justify-between space-y-6 md:space-y-0">
    <ul>
    
    </ul>
 
  </div>
</section>
<section class="is-title-bar">
  <div class="flex flex-col md:flex-row items-center justify-between space-y-6 md:space-y-0">
    <ul>
     
    </ul>
    
  </div>
</section>

<section class="is-hero-bar">
  <div class="flex flex-col md:flex-row items-center justify-between space-y-6 md:space-y-0">
    <h1 class="title">
      OWNER FEEDBACK
    </h1>

  </div>
</section>

  <section class="section main-section">
   
    <div class="card has-table">
      <header class="card-header">
        <p class="card-header-title">
          <span class="icon"><i class="mdi mdi-account-multiple"></i></span>
          Owner Feedback
        </p>
        <a href="#" class="card-header-icon">
          <span class="icon"><i class="mdi mdi-reload"></i></span>
        </a>
      </header>
      <div class="card-content">
        <table>
          <thead>
          <tr>
          <th></th>
            <th class="image-cell"></th>
           
            <th>Owner</th>
            <th>Customer</th>
            <th>Phone</th>
            <th>Complaint</th>
          </tr>
          </thead>
          <?php
include 'connection.php';
$query="select * from owner_feedback";
$res=mysqli_query($link,$query);
$v=0;
while($row=mysqli_fetch_array($res))

{
$v++;

$b=$row['id'];
$h=$row['owner_name'];
$c=$row['cust_name'];
$i=$row['cust_phone'];
$j=$row['complaint'];



?>
          <tbody>
          <tr>
            <td class="checkbox-cell">
              <label class="checkbox">
                <input type="checkbox">
                <span class="check"></span>
              </label>
            </td>
            <td class="image-cell">
              <div class="image">
                <img src="https://avatars.dicebear.com/v2/initials/rebecca-bauch.svg" class="rounded-full">
              </div>
            </td>
            <td data-label="Owner"><?php echo $h;?></td>
            <td data-label="Customer"><?php echo $c;?></td>
           
            <td data-label="Phone"><?php echo $i;?></td>
            <td data-label="Complaint"><?php echo $j;?></td>
        
            
          
           
            <td class="actions-cell">
              <div class="buttons right nowrap">
                
                <!-- <button class="button small red --jb-modal" data-target="sample-modal" type="button">
                  <span class="icon"><i class="mdi mdi-trash-can"></i></span>
                </button> -->
              </div>
            </td>
          </tr>
          <div id="sample-modal" class="modal">
  <div class="modal-background --jb-modal-close"></div>
  <div class="modal-card">
    <header class="modal-card-head">
      <p class="modal-card-title">Delete</p>
    </header>
    <section class="modal-card-body">
      <!-- <p>Lorem ipsum dolor sit amet <b>adipiscing elit</b></p> -->
      <p>Are you sure to delete this user</p>
    </section>
    <footer class="modal-card-foot">
      <!-- <button class="button --jb-modal-close">Cancel</button>
      <a href="deleteprocess.php"><button class="button red --jb-modal-close" name="delete">Confirm</button></a> -->
    </footer>
  </div>
</div>

</div>
          <?php
}
?>
          
          </tbody>
        </table>
       
      </div>
    </div>
  </section>

  
  <!-- <section class="section main-section">
    <div class="card mb-6">
      <header class="card-header">
        <p class="card-header-title">
          <span class="icon"><i class="mdi mdi-ballot"></i></span>
          ADD OWNERS
        </p>
      </header>
      <div class="card-content">
        <form action="add.php" method="post" enctype="multipart/form-data">
          <div class="field">
            <label class="label">From</label>
            <div class="field-body">
              <div class="field">
                <div class="control icons-left">
                  <input class="input" type="text" name="a" placeholder="Name">
                  <span class="icon left"><i class="mdi mdi-account"></i></span>
                </div>
              </div>
              <div class="field">
                <div class="control icons-left icons-right">
                  <input class="input" type="email" name="b" placeholder="alex@smith.com">
                  <span class="icon left"><i class="mdi mdi-mail"></i></span>
                  <span class="icon right"><i class="mdi mdi-check"></i></span>
                </div>
              </div>
            </div>
          </div>
          <div class="field">
            <div class="field-body">
              <div class="field">
                <div class="field addons">
                  <div class="control">
                    <input class="input" value="+91" size="3" readonly>
                  </div>
                  <div class="control expanded">
                    <input class="input" type="tel" name="c" placeholder="Your phone number">
                  </div>
                </div>
                <p class="help">Do not enter the first zero</p>
              </div>
            </div>
          </div>
          <div class="field">
            <label class="label">Place</label>
            <div class="control">
              <div class="control expanded">
                <input class="input" type="tel" name="d" placeholder="Your Place">
              </div>
            </div>
          </div>
          <hr>
          <div class="field">
            <label class="label">Password</label>

            <div class="control">
              <input class="input" type="text" name="e" placeholder="password">
            </div>
            <p class="help">
              This field is required
            </p>
          </div>
          <div class="field">
          <label class="upload control">
                <a class="button blue">
                  Upload
                </a>
                <input type="file" name="img" id="img" required><br><br>
              </label>
            <p class="help">
              This field is required
            </p>
          </div>

           

          <div class="field grouped">
            <div class="control">
            <button type="submit" name="upload" class="button green">
                Submit
              </button>
            </div>
            <div class="control">
              <button type="reset" class="button red">
                Reset
              </button>
            </div>
          </div>
        </form>
      </div>
    </div> -->


</div>
  



<script type="text/javascript" src="js/main.min.js?v=1652870200386"></script>


<script>
  !function(f,b,e,v,n,t,s)
  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
    n.callMethod.apply(n,arguments):n.queue.push(arguments)};
    if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
    n.queue=[];t=b.createElement(e);t.async=!0;
    t.src=v;s=b.getElementsByTagName(e)[0];
    s.parentNode.insertBefore(t,s)}(window, document,'script',
    'https://connect.facebook.net/en_US/fbevents.js');
  fbq('init', '658339141622648');
  fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=658339141622648&ev=PageView&noscript=1"/></noscript>

<!-- Icons below are for demo only. Feel free to use any icon pack. Docs: https://bulma.io/documentation/elements/icon/ -->
<link rel="stylesheet" href="https://cdn.materialdesignicons.com/4.9.95/css/materialdesignicons.min.css">

</body>
</html>
