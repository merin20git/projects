<?php

include 'connection.php';
if(isset($_POST['upload']))
{
$name=$_POST['a'];
$email=$_POST['b'];
$place=$_POST['d'];
$phone=$_POST['c'];
$pass=$_POST['e'];

$pic=$_FILES["img"]["name"];
$tmp=$_FILES["img"]["tmp_name"];
$type=$_FILES["img"]["type"];

 
$path="img/".$pic;

$query="insert into owner(name,email,place,phone,password,image) values('$name','$email','$place','$phone','$pass','$pic')";
$res=mysqli_query($link,$query);

if($res)
{
  move_uploaded_file($tmp,$path);
    ?>
    <script language="javascript">alert('Add successfull');
    window.location.replace('tables.php');</script>
    <?php
   }
else
{
  echo "error".$query."<br>".mysqli_error($link);
}

}
?>