<?php
include 'connection.php';
$b=$_GET['id'];
$status="approved";
$query="update owner set status='$status' where id='$b'";
$res=mysqli_query($link,$query);
if($res)
{
?>
<script language="javascript">alert('approved successfully');window.location.replace('tables.php');</script>

<?php
}
else
{
?>

<script language="javascript">alert('approve failed');window.location.replace('tables.php');</script>

<?php
}

?>
