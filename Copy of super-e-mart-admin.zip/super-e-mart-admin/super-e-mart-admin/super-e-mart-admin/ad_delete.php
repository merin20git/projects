<?php
include 'connection.php';
$b=$_GET['id'];
$query="delete from advertisement where id='$b'";
$res=mysqli_query($link,$query);
if($res)
{
?>
<script language="javascript">alert('deleted successfully');window.location.replace('advertisement.php');</script>

<?php
}
else
{
?>

<script language="javascript">alert('deletion failed');window.location.replace('advertisement.php');</script>

<?php
}

?>
